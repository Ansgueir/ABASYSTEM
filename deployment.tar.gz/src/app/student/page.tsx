import DashboardLayout from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { CalendarDays, Clock, DollarSign, ArrowRight } from "lucide-react"
import { auth } from "@/auth"
import { prisma } from "@/lib/prisma"
import { redirect } from "next/navigation"
import { startOfMonth } from "date-fns"
import { LogHoursDialog } from "@/components/log-hours-dialog"

export default async function StudentDashboard() {
    let session = null;
    try {
        session = await auth()
    } catch (error) {
        console.error("Auth session check failed:", error)
        // If auth fails completely, redirect to login
        redirect("/login")
    }

    if (!session || !session.user) {
        console.log("❌ Debug: No session or user found in dashboard")
        redirect("/login")
    }

    // console.log("✅ Debug: Session User Role:", session.user.role)

    // Normalized check
    const role = String((session.user as any).role).toLowerCase();

    if (role !== "student") {
        console.error("❌ Auth Error: Role mismatch. Expected 'student', got:", (session.user as any).role)
        redirect("/login")
    }

    // --- SAFE DB FETCHING START ---
    let student = null;
    let stats = {
        hoursThisMonth: 0,
        maxHours: 130, // Default fallback
        totalProgress: 0,
        totalRequired: 2000,
        nextPayment: 0,
        dueDate: "March 1st"
    };
    let dbError = false;

    try {
        student = await prisma.student.findUnique({
            where: { userId: session.user.id }
        })

        if (student) {
            // Safe Hours Calculation
            const currentMonthStart = startOfMonth(new Date())

            // Use Promise.allSettled to prevent one query failure from breaking everything
            const [indepMonth, supMonth, indepTotal, supTotal] = await Promise.all([
                prisma.independentHour.aggregate({
                    where: { studentId: student.id, date: { gte: currentMonthStart } },
                    _sum: { hours: true }
                }),
                prisma.supervisionHour.aggregate({
                    where: { studentId: student.id, date: { gte: currentMonthStart } },
                    _sum: { hours: true }
                }),
                prisma.independentHour.aggregate({
                    where: { studentId: student.id },
                    _sum: { hours: true }
                }),
                prisma.supervisionHour.aggregate({
                    where: { studentId: student.id },
                    _sum: { hours: true }
                })
            ])

            const hoursThisMonth = (Number(indepMonth?._sum?.hours) || 0) + (Number(supMonth?._sum?.hours) || 0)
            const totalProgress = (Number(indepTotal?._sum?.hours) || 0) + (Number(supTotal?._sum?.hours) || 0)

            stats = {
                hoursThisMonth,
                maxHours: student.hoursPerMonth || 130,
                totalProgress,
                totalRequired: 2000,
                nextPayment: Number(student.amountToPay) || 0,
                dueDate: "March 1st"
            }
        }

    } catch (error) {
        console.error("Database fetching failed for Dashboard:", error);
        dbError = true;
        // We continue rendering with default 'stats' and 'student=null'
    }
    // --- SAFE DB FETCHING END ---

    const displayName = student?.fullName?.split(' ')[0] || "Student";

    return (
        <DashboardLayout role="student">
            <div className="space-y-8">
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-3xl font-bold text-white">Welcome back, {displayName}.</h1>
                        <p className="text-slate-400 mt-1">Here's what's happening with your supervision.</p>
                        {dbError && (
                            <span className="inline-block px-2 py-1 mt-2 text-xs font-semibold text-red-400 bg-red-900/30 border border-red-800 rounded">
                                System Alert: Some data could not be loaded.
                            </span>
                        )}
                    </div>
                    <LogHoursDialog />
                </div>

                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    <Card className="bg-slate-900 border-slate-800 text-white">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-slate-400">Hours This Month</CardTitle>
                            <Clock className="h-4 w-4 text-indigo-400" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{stats.hoursThisMonth.toFixed(1)} <span className="text-sm text-slate-500 font-normal">/ {stats.maxHours} hrs</span></div>
                            <Progress value={(stats.hoursThisMonth / stats.maxHours) * 100} className="mt-3 h-2 bg-slate-800" indicatorClassName="bg-indigo-500" />
                            <p className="text-xs text-slate-500 mt-2">{Math.round((stats.hoursThisMonth / stats.maxHours) * 100)}% of monthly cap used</p>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900 border-slate-800 text-white">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-slate-400">Total Progress</CardTitle>
                            <CalendarDays className="h-4 w-4 text-emerald-400" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">{stats.totalProgress.toFixed(1)} <span className="text-sm text-slate-500 font-normal">/ {stats.totalRequired} hrs</span></div>
                            <Progress value={(stats.totalProgress / stats.totalRequired) * 100} className="mt-3 h-2 bg-slate-800" indicatorClassName="bg-emerald-500" />
                            <p className="text-xs text-slate-500 mt-2">{Math.round((stats.totalProgress / stats.totalRequired) * 100)}% towards certification</p>
                        </CardContent>
                    </Card>

                    <Card className="bg-slate-900 border-slate-800 text-white">
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                            <CardTitle className="text-sm font-medium text-slate-400">Next Payment</CardTitle>
                            <DollarSign className="h-4 w-4 text-orange-400" />
                        </CardHeader>
                        <CardContent>
                            <div className="text-2xl font-bold">${stats.nextPayment.toFixed(2)}</div>
                            <p className="text-xs text-slate-400 mt-1">Due by {stats.dueDate}</p>
                            <Button variant="link" className="px-0 text-indigo-400 h-auto mt-2 text-xs">
                                View Invoice <ArrowRight className="ml-1 h-3 w-3" />
                            </Button>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </DashboardLayout>
    )
}
