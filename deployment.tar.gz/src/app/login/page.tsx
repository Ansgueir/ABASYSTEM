"use client"

import { useState } from "react"
import { signIn } from "next-auth/react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { GraduationCap, Briefcase, Building2, Loader2 } from "lucide-react"

export default function LoginPage() {
    const router = useRouter()
    const [isLoading, setIsLoading] = useState(false)
    const [role, setRole] = useState<"student" | "supervisor" | "office">("student")
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [error, setError] = useState("")

    const handleLogin = async (e: React.FormEvent) => {
        e.preventDefault()
        setIsLoading(true)
        setError("")

        try {
            const result = await signIn("credentials", {
                redirect: false,
                email,
                password,
            })

            if (result?.error) {
                setError("Invalid credentials")
            } else {
                if (role === "student") router.push("/student")
                else if (role === "supervisor") router.push("/supervisor")
                else if (role === "office") router.push("/office")
            }
        } catch (err) {
            setError("An unexpected error occurred")
        } finally {
            setIsLoading(false)
        }
    }

    return (
        <div className="flex min-h-screen items-center justify-center bg-slate-950 p-4">
            <Card className="w-full max-w-md border-slate-800 bg-slate-900 text-slate-100 shadow-xl">
                <CardHeader className="space-y-1 text-center">
                    <div className="flex justify-center mb-4">
                        <div className="rounded-full bg-indigo-500/20 p-4">
                            <GraduationCap className="h-10 w-10 text-indigo-400" />
                        </div>
                    </div>
                    <CardTitle className="text-2xl font-bold tracking-tight text-white">
                        ABA Supervision System
                    </CardTitle>
                    <CardDescription className="text-slate-400">
                        Enter your credentials to access your portal
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-3 gap-2 mb-6">
                        <Button
                            variant={role === "student" ? "default" : "outline"}
                            className={`flex flex-col h-20 items-center justify-center space-y-2 ${role === "student" ? "bg-indigo-600 hover:bg-indigo-700 border-indigo-500" : "bg-transparent border-slate-700 hover:bg-slate-800 text-slate-400"}`}
                            onClick={() => setRole("student")}
                            type="button"
                        >
                            <GraduationCap className="h-6 w-6" />
                            <span className="text-xs">Student</span>
                        </Button>
                        <Button
                            variant={role === "supervisor" ? "default" : "outline"}
                            className={`flex flex-col h-20 items-center justify-center space-y-2 ${role === "supervisor" ? "bg-orange-600 hover:bg-orange-700 border-orange-500" : "bg-transparent border-slate-700 hover:bg-slate-800 text-slate-400"}`}
                            onClick={() => setRole("supervisor")}
                            type="button"
                        >
                            <Briefcase className="h-6 w-6" />
                            <span className="text-xs">Supervisor</span>
                        </Button>
                        <Button
                            variant={role === "office" ? "default" : "outline"}
                            className={`flex flex-col h-20 items-center justify-center space-y-2 ${role === "office" ? "bg-emerald-600 hover:bg-emerald-700 border-emerald-500" : "bg-transparent border-slate-700 hover:bg-slate-800 text-slate-400"}`}
                            onClick={() => setRole("office")}
                            type="button"
                        >
                            <Building2 className="h-6 w-6" />
                            <span className="text-xs">Office</span>
                        </Button>
                    </div>

                    <form onSubmit={handleLogin} className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="email" className="text-slate-200">Email</Label>
                            <Input
                                id="email"
                                type="email"
                                placeholder="name@example.com"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-slate-100 placeholder:text-slate-500 focus:ring-indigo-500 focus:border-indigo-500"
                                required
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="password" className="text-slate-200">Password</Label>
                            <Input
                                id="password"
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="bg-slate-800 border-slate-700 text-slate-100 focus:ring-indigo-500 focus:border-indigo-500"
                                required
                            />
                        </div>

                        {error && (
                            <div className="text-red-400 text-sm text-center bg-red-900/20 p-2 rounded border border-red-900/50">
                                {error}
                            </div>
                        )}

                        <Button
                            type="submit"
                            className="w-full bg-white text-slate-900 hover:bg-slate-200 font-semibold"
                            disabled={isLoading}
                        >
                            {isLoading ? (
                                <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    Signing in...
                                </>
                            ) : (
                                "Sign In"
                            )}
                        </Button>
                    </form>
                </CardContent>
                <CardFooter className="flex justify-center border-t border-slate-800 bg-slate-900/50 pt-4">
                    <p className="text-xs text-slate-500">
                        ABA Supervision System v1.0
                    </p>
                </CardFooter>
            </Card>
        </div>
    )
}
