import { auth } from "@/auth"
import { redirect } from "next/navigation"

export default async function Home() {
  const session = await auth()

  if (session?.user) {
    if (String((session.user as any).role).toLowerCase() === "student") {
      redirect("/student")
    }
    // Fallback for other roles or default
    redirect("/student")
  } else {
    redirect("/login")
  }
}
