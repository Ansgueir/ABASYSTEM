"use server"

import { z } from "zod"
import { auth } from "@/auth"
import { prisma } from "@/lib/prisma"
import { revalidatePath } from "next/cache"
import { ActivityType, SettingType, SupervisionFormat } from "@prisma/client"

const logHoursSchema = z.object({
    type: z.enum(["independent", "supervision"]),
    date: z.date(),
    startTime: z.string().min(1, "Start time is required"),
    minutes: z.preprocess((a) => parseInt(String(a), 10), z.number().min(1, "Duration must be at least 1 minute")), // User inputs minutes
    setting: z.nativeEnum(SettingType),
    activityType: z.nativeEnum(ActivityType),
    notes: z.string().optional(),
    supervisorId: z.string().optional(),
    supervisionFormat: z.nativeEnum(SupervisionFormat).optional(),
})

export type LogHoursState = {
    success?: boolean
    error?: string
    fieldErrors?: Record<string, string[]>
}

export async function logHours(prevState: LogHoursState, formData: FormData) {
    const session = await auth()
    if (!session || !session.user || String((session.user as any).role).toLowerCase() !== "student") {
        return { error: "Unauthorized" }
    }

    // Parse Date carefully
    const rawDate = formData.get("date") as string
    const dateObj = new Date(rawDate)

    // Log raw data for debugging
    console.log("Saving Log:", {
        type: formData.get("type"),
        date: rawDate,
        startTime: formData.get("startTime"),
        minutes: formData.get("minutes"),
        setting: formData.get("setting"),
        activityType: formData.get("activityType"),
    })

    // Parse other fields
    const rawData = {
        type: formData.get("type"),
        date: dateObj,
        startTime: formData.get("startTime"),
        minutes: formData.get("minutes"),
        setting: formData.get("setting"),
        activityType: formData.get("activityType"),
        notes: formData.get("notes") || undefined,
        supervisorId: formData.get("supervisorId") || undefined,
        supervisionFormat: formData.get("supervisionFormat") || undefined,
    }

    const validatedFields = logHoursSchema.safeParse(rawData)

    if (!validatedFields.success) {
        const errors = validatedFields.error.flatten().fieldErrors;
        const errorMessage = Object.entries(errors).map(([key, msgs]) => `${key}: ${msgs?.join(", ")}`).join("; ");
        console.error("Validation Errors:", errorMessage)
        return {
            error: "Validation failed: " + errorMessage,
            fieldErrors: errors,
        }
    }

    const data = validatedFields.data

    // Calculate hours decimal
    const hoursDecimal = data.minutes / 60

    try {
        const student = await prisma.student.findUnique({
            where: { userId: session.user.id }
        })

        if (!student) return { error: "Student profile not found" }

        // Combine date + start time for the startTime DateTime field
        const [hours, mins] = data.startTime.split(':').map(Number)
        const startDateTime = new Date(data.date)
        startDateTime.setHours(hours, mins, 0, 0)


        if (data.type === "independent") {
            await prisma.independentHour.create({
                data: {
                    studentId: student.id,
                    date: data.date,
                    startTime: startDateTime,
                    hours: hoursDecimal,
                    setting: data.setting,
                    activityType: data.activityType,
                    notes: data.notes,
                }
            })
        } else {
            // Logic for supervision
            // For MVP, we assume they have a supervisor assigned or we pick one.
            // If supervisorId is not selected, use student's default.

            let supervisorId = data.supervisorId
            if (!supervisorId && student.supervisorId) {
                supervisorId = student.supervisorId
            }

            if (!supervisorId) {
                return { error: "No supervisor selected and none assigned to profile." }
            }

            await prisma.supervisionHour.create({
                data: {
                    studentId: student.id,
                    supervisorId: supervisorId,
                    date: data.date,
                    startTime: startDateTime,
                    hours: hoursDecimal,
                    setting: data.setting,
                    activityType: data.activityType,
                    supervisionType: data.supervisionFormat || SupervisionFormat.INDIVIDUAL,
                    notes: data.notes,
                }
            })
        }

        revalidatePath("/student")
        return { success: true }

    } catch (err) {
        console.error("Failed to log hours:", err)
        return { error: "Database error occurred." }
    }
}
