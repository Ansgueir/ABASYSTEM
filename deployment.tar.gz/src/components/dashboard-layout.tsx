"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
    LayoutDashboard,
    Users,
    FileText,
    CreditCard,
    Settings,
    LogOut,
    Menu,
    X,
    GraduationCap
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"

interface SidebarProps {
    role: "student" | "supervisor" | "office"
}

export default function DashboardLayout({
    children,
    role = "student" // Default for dev, will come from auth
}: {
    children: React.ReactNode
    role?: "student" | "supervisor" | "office"
}) {
    const [isSidebarOpen, setIsSidebarOpen] = useState(false)
    const pathname = usePathname()

    const routes = {
        student: [
            { name: "Dashboard", href: "/student", icon: LayoutDashboard },
            { name: "Timesheet", href: "/student/timesheet", icon: FileText },
            { name: "Payments", href: "/student/payments", icon: CreditCard },
            { name: "Documents", href: "/student/documents", icon: FileText },
            { name: "Profile", href: "/student/profile", icon: Users },
        ],
        supervisor: [
            { name: "Dashboard", href: "/supervisor", icon: LayoutDashboard },
            { name: "My Students", href: "/supervisor/students", icon: Users },
            { name: "Timesheet Entry", href: "/supervisor/timesheet", icon: FileText },
            { name: "Payments", href: "/supervisor/payments", icon: CreditCard },
            { name: "Profile", href: "/supervisor/profile", icon: Settings },
        ],
        office: [
            { name: "Dashboard", href: "/office", icon: LayoutDashboard },
            { name: "Students", href: "/office/students", icon: GraduationCap },
            { name: "Supervisors", href: "/office/supervisors", icon: Users },
            { name: "Payments", href: "/office/payments", icon: CreditCard },
            { name: "Group Supervision", href: "/office/group-supervision", icon: Users },
            { name: "Settings", href: "/office/settings", icon: Settings },
        ]
    }

    const currentRoutes = routes[role]

    return (
        <div className="min-h-screen bg-slate-950 text-slate-100">
            {/* Mobile Header */}
            <div className="lg:hidden flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900">
                <div className="font-bold text-xl text-white">ABA System</div>
                <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
                    <SheetTrigger asChild>
                        <Button variant="ghost" size="icon">
                            <Menu className="h-6 w-6" />
                        </Button>
                    </SheetTrigger>
                    <SheetContent side="left" className="w-64 bg-slate-900 border-r-slate-800 p-0 text-white">
                        <SidebarContent routes={currentRoutes} pathname={pathname} />
                    </SheetContent>
                </Sheet>
            </div>

            <div className="flex h-screen overflow-hidden">
                {/* Desktop Sidebar */}
                <aside className="hidden lg:flex w-64 flex-col border-r border-slate-800 bg-slate-900">
                    <SidebarContent routes={currentRoutes} pathname={pathname} />
                </aside>

                {/* Main Content */}
                <main className="flex-1 overflow-y-auto p-4 lg:p-8 bg-slate-950">
                    <div className="mx-auto max-w-7xl">
                        {children}
                    </div>
                </main>
            </div>
        </div>
    )
}

function SidebarContent({ routes, pathname }: { routes: any[], pathname: string }) {
    return (
        <div className="flex flex-col h-full bg-slate-900 text-slate-100">
            <div className="flex items-center h-16 px-6 border-b border-slate-800">
                <GraduationCap className="h-6 w-6 text-indigo-500 mr-2" />
                <span className="font-bold text-lg">ABA Supervision</span>
            </div>

            <div className="flex-1 py-6 px-3 space-y-1 overflow-y-auto">
                {routes.map((route) => {
                    const Icon = route.icon
                    const isActive = pathname === route.href

                    return (
                        <Link
                            key={route.href}
                            href={route.href}
                            className={cn(
                                "flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-colors",
                                isActive
                                    ? "bg-indigo-600/10 text-indigo-400"
                                    : "text-slate-400 hover:text-white hover:bg-slate-800"
                            )}
                        >
                            <Icon className={cn("h-5 w-5 mr-3", isActive ? "text-indigo-400" : "text-slate-500")} />
                            {route.name}
                        </Link>
                    )
                })}
            </div>

            <div className="p-4 border-t border-slate-800">
                <div className="flex items-center mb-4">
                    <Avatar className="h-9 w-9 border border-slate-700">
                        <AvatarImage src="/placeholder-user.jpg" />
                        <AvatarFallback className="bg-slate-800 text-indigo-400">JD</AvatarFallback>
                    </Avatar>
                    <div className="ml-3">
                        <p className="text-sm font-medium text-white">John Doe</p>
                        <p className="text-xs text-slate-500">Student</p>
                    </div>
                </div>
                <Button variant="outline" className="w-full justify-start border-slate-700 text-slate-400 hover:text-white hover:bg-slate-800">
                    <LogOut className="mr-2 h-4 w-4" />
                    Log Out
                </Button>
            </div>
        </div>
    )
}
