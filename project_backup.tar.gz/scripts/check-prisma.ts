import { UserRole } from '@prisma/client'

console.log('UserRole enum values:', UserRole)
